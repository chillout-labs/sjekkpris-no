# SjekkPris – konkret valideringspakke v0.1

Dato: 6. oktober 2026. Status: begrenset lokal validering – ikke produksjonsgodkjenning.

## Hva pakken er

Kjørbare, nettverksfrie tester av foreslåtte URL- og prisvisningsregler. Dette er ikke Chillout-kode, ikke Googles validator, og ikke en sertifisering av Web Standard. De tidligere stress-testdokumentene beskriver scenarier; de er ikke dokumentasjon på at disse scenariene er kjørt mot en implementasjon.

## Faktisk kjørt

`python validate_contract.py`

Python 3.10 eller nyere, bare standardbiblioteket. Ingen nettverk, database, affiliate-klikk eller produksjonsskriving. Programmet skriver testresultater i denne mappen.

Siste kjøring: 31 tester, 0 feil, 0 unntak. Resultatene finnes i `test-summary.json` og `test-output.txt`.

16 tester gjelder URL-navn og en enkel livssyklusmodell. 15 tester gjelder et syntetisk tilbudssett og intern konsistens i en kandidat til strukturert data.

## Reelt, men lite produktutvalg

`real_product_sample.json` inneholder 19 manuelt avskrevne, komplette navn/id/slug-poster fra lesbare GitHub-utdrag: fem kontaktlinseprodukter og fjorten linsevæsker. Fil- og blobreferanser følger hver post. Ingen priser eller medisinske beskrivelser er tatt med.

Dette er et bekvemmelighetsutvalg, ikke et tilfeldig eller representativt utvalg av SjekkPris. Det tester ikke hele Kontaktlinser-katalogen, CDON, Babysjarm eller Chillouts produksjonsdatabase. Navnetesten verifiserer ikke GTIN, produktidentitet eller variantrelasjon.

19 navn gir 19 forskjellige kandidat-slugs i dette utvalget. Alle 19 samsvarer med de avleste eksisterende slugstrengene. Dette sier ikke at nåværende Kontaktlinser-URL-er skal flyttes. `/produkt/...` er kun et SjekkPris-forslag i testen.

## Syntetiske kanttilfeller

DemoRegistry illustrerer fryste slugs, eksplisitt navnebytte, historiske aliaser og avvisning av kollisjon. En eksisterende offentlig id brukes som reserve-suffiks i demonstrasjonen. Produksjonsstrategien for suffiks/navnedisambiguering er ikke godkjent gjennom disse testene. Modellen har ingen database og beviser ikke samtidighet, transaksjoner, global unicitet eller migrering.

Normaliseringstesten viser blant annet hvorfor et URL-navn ikke er en produktidentitet: «A/B» og «A B» gir samme grunnslug. Registry-modellen skal oppdage kollisjonen, ikke slå produktene sammen.

## Pris og schema

Alle tilbud i `schema-fixture.json` er oppdiktede testdata for samme fiktive vannkoker:

A: varepris 749 kr + frakt 99 kr = 848 kr.
B: varepris 799 kr + bekreftet frakt 0 kr = 799 kr.
C: varepris 699 kr + ukjent frakt = ukjent totalpris.

B er laveste kjente totalpris. C er laveste varepris, men ikke en bekreftet totalprisvinner. Ved et hardt totalbudsjett kan C ikke påstås å passe uten fraktavklaring; C er heller ikke bevist for dyr.

`comparable()` avgrenser akkurat disse testenes vinnerutvalg til ferske, lagerførte, eksakt like produkter i NOK. Det er ikke en generell instruks om å skjule bestillingsvarer/forhåndsbestillinger i SjekkPris.

JSON kan parses og pris/count-feltene samsvarer med fixture-utvalget. Google Rich Results Test, schema-validator og Search Console er IKKE kjørt. En slik test ville heller ikke alene bevise prisens forretningsmessige riktighet, rich-result-visning eller indeksering. Eksempeldomenet example.com og testbildet er bevisst ikke produksjonsressurser.

## Legacy-sjekk

`http-probe.json` dokumenterer mislykkede nettverksforsøk i dette arbeidsmiljøet. Det betyr IKKE at SjekkPris er nede eller returnerer disse statusene.

En separat webhenting fikk en mellomlagret representasjon av `/Shopping/Blomster/EuroFlorist.aspx` med dagens under-utviklingstekst. Dette er bare ett observert legacy-eksempel. Det dokumenterer ikke live HTTP-status, redirect, Google-indeksering eller en komplett gammel URL-liste.

## Clickout

Kun kildekode er lest. Ingen `/go/`-rute er kalt. Koden viser en eksisterende `GET /go/{target_token}` med 302 og no-store på vellykket redirect. Verifikasjonsskriptet beskriver at et ekte GET oppretter en klikkrad, selv uten viderehopp til nettverket. Det ble derfor ikke kjørt.

## Ikke ferdig / ikke testet

Stor katalogkollisjonstest; database-unikhet/samtidighet; komplett legacy-inventar og redirectkart; live SjekkPris HTTP/headers/CDN; virkelig property-isolasjon; clickout i produksjon; Googles validatorer; indeksresultater; hele variantmatrisen; mobil/performance/rendering i faktisk frontend.

## Neste dataleveranse

Et renset produktutvalg fra de faktiske lanseringskategoriene, gjerne titusener av produkter, med eksisterende produkt-id, tittel, merke, modell, relevant variant/pakning og eventuell eksisterende slug. Ikke inkluder secrets, API-nøkler, affiliate-URL-er eller persondata. Suppler med tilgjengelige SjekkPris URL-eksporter/legacy-kilder. Pakken kan videreutvikles av Work mot godkjent implementasjon.

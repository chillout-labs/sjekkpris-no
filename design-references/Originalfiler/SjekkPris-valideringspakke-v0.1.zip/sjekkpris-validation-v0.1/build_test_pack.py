from pathlib import Path
import json
P=Path(__file__).parent
lens=[
('acuvue-oasys-6pk','Acuvue Oasys 6-pack','acuvue-oasys-6-pack'),
('acuvue-vita-6pk','Acuvue Vita 6-pack','acuvue-vita-6-pack'),
('biofinity-6pk','Biofinity 6-pack','biofinity-6-pack'),
('acuvue-moist-30pk','1-Day Acuvue Moist 30-pack','1-day-acuvue-moist-30-pack'),
('acuvue-oasys-max-1day-30pk','Acuvue Oasys MAX 1-Day 30-pack','acuvue-oasys-max-1-day-30-pack')]
solutions=[
('renu-multipurpose-60ml','ReNu Multi-Purpose 60 ml','renu-multi-purpose-60-ml'),
('renu-multipurpose-240ml','ReNu Multi-Purpose 240 ml','renu-multi-purpose-240-ml'),
('renu-multipurpose-360ml','ReNu Multi-Purpose 360 ml','renu-multi-purpose-360-ml'),
('optifree-puremoist-90ml','Opti-Free PureMoist 90 ml','opti-free-puremoist-90-ml'),
('optifree-puremoist-300ml','Opti-Free PureMoist 300 ml','opti-free-puremoist-300-ml'),
('optifree-express-355ml','Opti-Free Express 355 ml','opti-free-express-355-ml'),
('optifree-express-120ml','Opti-Free Express 120 ml','opti-free-express-120-ml'),
('aosept-plus-360ml','AOSept Plus 360 ml','aosept-plus-360-ml'),
('easysept-360ml','EasySept 360 ml','easysept-360-ml'),
('easysept-120ml','EasySept 120 ml','easysept-120-ml'),
('solocare-aqua-360ml','SoloCare Aqua 360 ml','solocare-aqua-360-ml'),
('biotrue-solution-300ml','Biotrue 300 ml','biotrue-300-ml'),
('everclear-refresh-250ml','everclear REFRESH 250 ml','everclear-refresh-250-ml'),
('oxysept-1step-300ml','Oxysept 1-Step 300 ml','oxysept-1-step-300-ml')]
records=[]
for rows,file,sha in [(lens,'products_meta.json','82f9da0c3f66c281f4d2b600b1d1380356a957d3'),(solutions,'solutions_meta.json','3ebba3acb0a8af61a744223c9e50776af0fca36c')]:
 for i,n,s in rows:
  records.append(dict(source_id=i,title=n,existing_slug=s,source_file=file,source_blob_sha=sha))
(P/'real_product_sample.json').write_text(json.dumps({'scope':'19 manually extracted repository records: 5 contact-lens products and 14 lens-solution products. Not a random sample, not the SjekkPris launch catalog, not a canonical-identity audit. Prices, safety claims and descriptions intentionally excluded.','source_repository':'Hovedkvarter/Kontaktlinser-no','extraction':'Exact id, name, slug strings copied from current GitHub connector reads. Not a complete copy of either source file.','products':records},ensure_ascii=False,indent=2),encoding='utf8')

"""Offline design-contract checks. Not Chillout production code or Google's validator.

Python 3.10+, stdlib only. No network, no database, no third-party API calls.
Real sample checks are explicitly separate from synthetic edge-case fixtures.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from pathlib import Path
from collections import defaultdict
import json
import re
import unicodedata
import unittest

ROOT=Path(__file__).resolve().parent


def slugify(value: str) -> str:
    """Proposed Norwegian transliteration, NOT an identity resolver."""
    value=unicodedata.normalize('NFKC',value).casefold()
    value=value.translate(str.maketrans({'æ':'ae','ø':'o','å':'a'}))
    value=value.replace('+',' plus ')
    value=''.join(c for c in unicodedata.normalize('NFKD',value) if not unicodedata.combining(c))
    value=re.sub(r'[^a-z0-9]+','-',value).strip('-')
    if not value:
        raise ValueError('No readable slug; explicit naming decision required')
    return value


class DemoRegistry:
    """In-memory lifecycle model only. Does NOT prove DB transactions/concurrency."""
    def __init__(self) -> None:
        self.owner: dict[str,str]={}
        self.current: dict[str,str]={}
        self.redirects: dict[str,str]={}
        self.retired: set[str]=set()

    def allocate(self, public_id: str, title: str) -> str:
        if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',public_id):
            raise ValueError('Expected existing opaque public id, not provider id')
        if public_id in self.current:
            return self.current[public_id]
        base=slugify(title)
        candidate=base
        if candidate in self.owner:
            candidate=f'{base}-{public_id}'
        if candidate in self.owner:
            raise ValueError('Collision unresolved: review; do not overwrite')
        self.owner[candidate]=public_id
        self.current[public_id]=candidate
        return candidate

    def explicit_rename(self, public_id: str, new_slug: str) -> str:
        if public_id in self.retired:
            raise ValueError('Retired identities need explicit recovery, not rename')
        if slugify(new_slug)!=new_slug:
            raise ValueError('Rename requires normalized explicit slug')
        old=self.current[public_id]
        if old==new_slug:
            return old
        if new_slug in self.owner:
            raise ValueError('Historical or current slug is already reserved')
        self.owner[new_slug]=public_id
        self.current[public_id]=new_slug
        for src in list(self.redirects):
            if self.owner.get(src)==public_id:
                self.redirects[src]=new_slug
        self.redirects[old]=new_slug
        return new_slug

    def retire(self, public_id: str) -> None:
        # Deliberately keep current/owner/redirect reservations.
        self.retired.add(public_id)


@dataclass(frozen=True)
class Offer:
    id: str
    product: str
    item_minor: int
    shipping_minor: int | None
    currency: str='NOK'
    state: str='in_stock'
    fresh: bool=True
    def __post_init__(self) -> None:
        if self.item_minor<0 or (self.shipping_minor is not None and self.shipping_minor<0):
            raise ValueError('Negative fixture price')


def comparable(offers: list[Offer],product: str) -> list[Offer]:
    """Fixture scope: confirmed current in-stock, exact product, Norwegian offers.

    This is not a proposal to hide all backorders/preorders in the real UI.
    It defines the immediate-purchase winner cohort for these tests only.
    """
    return [o for o in offers if o.product==product and o.currency=='NOK' and o.fresh and o.state=='in_stock']


def summarize(offers: list[Offer],product: str) -> dict:
    rows=comparable(offers,product)
    known=[(o.item_minor+o.shipping_minor,o.id) for o in rows if o.shipping_minor is not None]
    return dict(offer_count=len(rows),item_low_minor=min((o.item_minor for o in rows),default=None),
                lowest_known_total_minor=min((v for v,_ in known),default=None),
                known_total_winner=min(known)[1] if known else None,
                unknown_shipping_count=sum(o.shipping_minor is None for o in rows))


def product_schema(offers: list[Offer],product: str) -> dict:
    """Candidate item-price profile; NO claim of Google Rich Results validation."""
    doc={'@context':'https://schema.org','@type':'Product','name':'Fiktiv testvannkoker',
         'url':'https://example.com/produkt/testvannkoker',
         'image':'https://example.com/assets/testvannkoker.jpg'}
    rows=comparable(offers,product)
    if rows:
        doc['offers']={'@type':'AggregateOffer','priceCurrency':'NOK',
                       'lowPrice':f'{min(o.item_minor for o in rows)/100:.2f}',
                       'highPrice':f'{max(o.item_minor for o in rows)/100:.2f}',
                       'offerCount':len(rows)}
    return doc


FIX=[Offer('A','kettle',74900,9900),Offer('B','kettle',79900,0),Offer('C','kettle',69900,None)]


class SlugChecks(unittest.TestCase):
    def test_real_names_are_unique_in_small_sample(self):
        rows=json.loads((ROOT/'real_product_sample.json').read_text(encoding='utf8'))['products']
        slugs=[slugify(r['title']) for r in rows]
        self.assertEqual(len(slugs),len(set(slugs)))
    def test_sample_preserves_current_slug_strings(self):
        rows=json.loads((ROOT/'real_product_sample.json').read_text(encoding='utf8'))['products']
        self.assertTrue(all(slugify(r['title'])==r['existing_slug'] for r in rows))
    def test_norwegian(self): self.assertEqual(slugify('Æ Ø Å øyedråper'),'ae-o-a-oyedraper')
    def test_unicode_equivalence(self): self.assertEqual(slugify('Øyedråper'),slugify(unicodedata.normalize('NFD','Øyedråper')))
    def test_decimal_not_integer(self): self.assertNotEqual(slugify('Motor 1,5 L'),slugify('Motor 15 L'))
    def test_plus_not_erased(self): self.assertNotEqual(slugify('Modell A+'),slugify('Modell A'))
    def test_two_pack_sizes(self): self.assertNotEqual(slugify('Produkt 30-pack'),slugify('Produkt 90-pack'))
    def test_safely_reject_empty(self):
        with self.assertRaises(ValueError): slugify('!!!')
    def test_slash_not_extra_path(self): self.assertEqual(slugify('A / B'),'a-b')
    def test_title_change_does_not_change_url(self):
        r=DemoRegistry(); old=r.allocate('p01','Modell C4'); self.assertEqual(old,r.allocate('p01','Ny tittel C4'))
    def test_taxonomy_not_in_product_route(self):
        r=DemoRegistry(); s=r.allocate('p01','Modell C4'); self.assertEqual('/produkt/'+s,'/produkt/modell-c4')
    def test_same_name_not_same_identity(self):
        r=DemoRegistry(); self.assertNotEqual(r.allocate('p01','Modell A'),r.allocate('p02','Modell A'))
    def test_retired_slug_cannot_be_recycled(self):
        r=DemoRegistry(); old=r.allocate('p01','Modell A');r.retire('p01'); self.assertNotEqual(old,r.allocate('p02','Modell A'))
    def test_redirects_flatten_after_rename(self):
        r=DemoRegistry(); old=r.allocate('p01','Modell A');r.explicit_rename('p01','modell-b');r.explicit_rename('p01','modell-c');self.assertEqual(r.redirects,{old:'modell-c','modell-b':'modell-c'})
    def test_rename_collision_refused(self):
        r=DemoRegistry();r.allocate('p01','Modell A');r.allocate('p02','Modell B')
        with self.assertRaises(ValueError): r.explicit_rename('p01','modell-b')
    def test_cosmetic_name_collision_is_detectable(self):
        self.assertEqual(slugify('A/B'),slugify('A B'))
        r=DemoRegistry();self.assertNotEqual(r.allocate('p01','A/B'),r.allocate('p02','A B'))


class OfferSchemaChecks(unittest.TestCase):
    def test_lowest_item_not_lowest_known_total(self):
        s=summarize(FIX,'kettle');self.assertEqual(s['item_low_minor'],69900);self.assertEqual(s['known_total_winner'],'B')
    def test_unknown_shipping_not_free(self):
        s=summarize(FIX,'kettle');self.assertEqual(s['unknown_shipping_count'],1);self.assertEqual(s['lowest_known_total_minor'],79900)
    def test_budget_requires_confirmed_total(self):
        eligible=[o.id for o in FIX if o.shipping_minor is not None and o.item_minor+o.shipping_minor<=80000];self.assertEqual(eligible,['B'])
    def test_no_offers_does_not_mean_zero_price(self):
        self.assertIsNone(summarize([],'kettle')['item_low_minor']);self.assertNotIn('offers',product_schema([],'kettle'))
    def test_one_offer(self): self.assertEqual(product_schema(FIX[:1],'kettle')['offers']['offerCount'],1)
    def test_stale_offer_not_current_winner(self):
        rows=FIX+[Offer('D','kettle',1,0,fresh=False)];self.assertEqual(summarize(rows,'kettle')['item_low_minor'],69900)
    def test_out_of_stock_not_in_immediate_winner_cohort(self):
        rows=FIX+[Offer('D','kettle',1,0,state='out_of_stock')];self.assertEqual(summarize(rows,'kettle')['item_low_minor'],69900)
    def test_other_currency_not_aggregated(self):
        self.assertEqual(summarize(FIX+[Offer('D','kettle',1,0,currency='SEK')],'kettle')['offer_count'],3)
    def test_distinct_product_variant_not_aggregated(self):
        self.assertEqual(summarize(FIX+[Offer('D','other-size',1,0)],'kettle')['offer_count'],3)
    def test_unknown_availability_not_in_immediate_winner_cohort(self):
        self.assertEqual(summarize(FIX+[Offer('D','kettle',1,0,state='unknown')],'kettle')['offer_count'],3)
    def test_schema_snapshot_values_match_item_basis(self):
        d=product_schema(FIX,'kettle')['offers'];s=summarize(FIX,'kettle');self.assertEqual(d['lowPrice'],f"{s['item_low_minor']/100:.2f}");self.assertEqual(d['offerCount'],s['offer_count'])
    def test_json_roundtrip(self):
        d=product_schema(FIX,'kettle');self.assertEqual(d,json.loads(json.dumps(d)))
    def test_no_fabricated_reviews(self):
        d=product_schema(FIX,'kettle');self.assertNotIn('review',d);self.assertNotIn('aggregateRating',d)
    def test_no_offer_product_is_separate_from_rich_result_eligibility(self):
        d=product_schema([],'kettle');self.assertEqual(d['@type'],'Product');self.assertFalse(any(k in d for k in ('review','aggregateRating','offers')))
    def test_negative_price_refused(self):
        with self.assertRaises(ValueError): Offer('D','kettle',-1,0)


if __name__=='__main__':
    rows=json.loads((ROOT/'real_product_sample.json').read_text(encoding='utf8'))['products']
    buckets=defaultdict(list)
    for r in rows: buckets[slugify(r['title'])].append(r['source_id'])
    (ROOT/'slug-sample-results.json').write_text(json.dumps({'sample_count':len(rows),'unique_candidate_slugs':len(buckets),'collision_groups':{k:v for k,v in buckets.items() if len(v)>1},'scope':'Small convenience sample. No broad-catalog or concurrent DB guarantee.','rows':[dict(source_id=r['source_id'],candidate_path='/produkt/'+slugify(r['title']),matches_current_slug=slugify(r['title'])==r['existing_slug']) for r in rows]},ensure_ascii=False,indent=2),encoding='utf8')
    (ROOT/'schema-fixture.json').write_text(json.dumps({'notice':'SYNTHETIC OFFERS; local internal consistency only; not Google validated','summary':summarize(FIX,'kettle'),'candidate_jsonld':product_schema(FIX,'kettle')},ensure_ascii=False,indent=2),encoding='utf8')
    with (ROOT/'test-output.txt').open('w',encoding='utf8') as f:
        suite=unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
        result=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
    summary={'suite':'offline contract demonstration, not production integration','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'success':result.wasSuccessful(),'not_tested':['production site','Google Rich Results Test','Search Console indexing','real Chillout API','DB transactions/concurrency','broad SjekkPris catalog','merchant clickout requests']}
    (ROOT/'test-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
